**Project Description**

WPF XML editor as such the name says it is an simple editor for any type of xml file. Tools developed on top of MVVM framework, the source code can also be re-used in your WPF or silverlight based projects.

The tool support multi-file, drag&drop and xpath search support. 

**Details**

The tool created by keeping an constant problem in mind which is syntax and parser error when build or support team work with various configuration files for your product. To work with this tool you need no knowledge of XML background. Also we have considered the MVVM pattern to give more extensible and reusablity feature to tlhe clients.

Usability point view, we decided to provide Visual Studio kind of UI for non programmer to work with the tool.

**Feature**

# WPF based xml editor.
# Extensible for any WPF/Silverlight developers.
# Easy use for support engineers.
# CRUD (creation,read,update,delete) operation via Mouse click.
# Simple self XPATH based navigation and search capability.

**Team**

#GomesNayagam [www.twitter.com/GomesNayagam](www.twitter.com/GomesNayagam)
#KovidPandey [www.twitter.com/pandeykovid](www.twitter.com/pandeykovid)

**Screenshot**

![](Home_screenshot.png)