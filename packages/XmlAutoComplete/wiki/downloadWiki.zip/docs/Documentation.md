# Let's start!

Using of **XmlAutoComplete** control is super simple! For a quick start I recommend you to have a look into a testing project where are 2 demo XSD files provided (one simple, one complex) so you can see immediately how **XmlAutoComplete** works. Just download _\Bin_ and _\DemoFiles_ folder and run _Testing.exe_. 

If you don't want to play with a demo and use it straight away, just follow these steps:

* In your project, add a reference to the XmlAutoComplete.dll 
* Open a XAML file where you want to add **XmlAutoComplete** and append this namespace so you can access it from the XAML later:
{code:xml}
xmlns:auto="clr-namespace:XmlAutoComplete;assembly=XmlAutoComplete"
{code:xml}
* Once you set this namespace use it later in the same XAML as:
{code:xml}
<auto:SuggestionTextBox x:Name="suggestion" />
{code:xml}
* or you can provide an options as well:
{code:xml}
<auto:SuggestionTextBox x:Name="suggestion" ElementAutoComplete="True" AppendNamespace="False"/>
{code:xml}
* after you defined **XmlAutoComplete** in a XAML, go to the code and attach an XSD file by using _XsdParser_ class:
{code:c#}
using XmlAutoComplete;
...
suggestion.Parser = new XsdParser("yourSchema.xsd");
{code:c#}
* To clear all text use:
{code:c#}
suggestion.Clear();
{code:c#}
* To get a text that is already written in the control, use property _Text_:
{code:c#}
suggestion.Text
{code:c#}