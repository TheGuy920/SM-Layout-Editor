# What is XmlAutoComplete?
XmlAutoComplete is a WPF (.NET4.0) control providing suggestions while writing XML according to a bounded schema.

# Your XML helper
We all love Visual Studio XML editor with helpful suggestions, but you cannot use it directly in your applications. XmlAutoComplete is a WPF control which will allow you to provide an auto-complete functionality while editing XML files in your applications.
Attach an XSD file and you can start typing!  

![](Home_demo.png)

**XmlAutoComplete** control provides suggestions for:
* Elements
* Attributes
* Attribute values

And it also:
* Auto-close elements
* Append namespaces into elements
